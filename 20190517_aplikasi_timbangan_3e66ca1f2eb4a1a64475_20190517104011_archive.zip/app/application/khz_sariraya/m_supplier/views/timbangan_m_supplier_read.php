
        <h2 style="margin-top:0px">Data Supplier</h2>
        <div class="box">
        <div class="box-body">
        <table class="table">
	    <tr><td>Nama</td><td><?php echo $nama; ?></td></tr>
	    <tr><td>Alamat</td><td><?php echo $alamat; ?></td></tr>
	    <tr><td>No Handphone</td><td><?php echo $no_handphone; ?></td></tr>
	    <tr><td>Email</td><td><?php echo $email; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo base_url('m_supplier') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>

